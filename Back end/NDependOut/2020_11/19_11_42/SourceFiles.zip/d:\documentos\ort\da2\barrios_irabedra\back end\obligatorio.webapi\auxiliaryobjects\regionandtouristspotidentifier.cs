﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Obligatorio.WebApi.AuxiliaryObjects
{
    public class RegionAndTouristSpotIdentifier
    {
        public string TouristSpotName { get; set; }
        public string RegionName { get; set; }
        public RegionAndTouristSpotIdentifier()
        {
        }
    }
}

    

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Obligatorio.WebApi.AuxiliaryObjects
{
    public class StringWrapper
    {
        public string FilePath { get; set; }
        public string BinaryPath { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Obligatorio.Migrations
{
    class Program
    {
        public static void Main()
        {

        }
    }
}

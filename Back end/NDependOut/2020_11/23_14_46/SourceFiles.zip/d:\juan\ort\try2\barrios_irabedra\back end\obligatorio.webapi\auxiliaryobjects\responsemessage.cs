﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Obligatorio.WebApi.AuxiliaryObjects
{
    public class ResponseMessage
    {
        public string Message { get; set; }
    }
}
